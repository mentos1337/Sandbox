print ("Hva er meningen med livet? ")

svar = int(input(""))

if svar == 42:
    print("Det stemmer, meningen med livet er 42")

elif svar > 30 and svar < 50:
    print("Nærme, men feil")

else:
    print("FEIL!")