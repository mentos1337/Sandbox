oddetall = [*range(9, 102, 2)]
for x in oddetall:
    print (x)

oddetallstart = 9
while oddetallstart < 102:
    print(oddetallstart)
    oddetallstart += 2