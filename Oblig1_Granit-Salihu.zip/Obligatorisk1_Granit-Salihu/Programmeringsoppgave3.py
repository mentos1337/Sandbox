print("Velg to tall som skal vrikkes og vendes")

tall1 = float(input("Tall nummer en: "))                # Lager variabel til tall nummer en
tall2 = float(input("Tall nummer to: "))                # Lager variabel til tall nummer to

print("Multiplisert =", tall1 * tall2)                  # Multipliserer variablene
print("Dividert =", tall1 / tall2)                      # Dividerer variablene
print("Addert =", tall1 + tall2)                        # Adderer variablene
print("Subtrahert =", tall1 - tall2)                    # Subtraherer variablene
print("Modulo =", tall1 % tall2)                        # Modulo av variablene
print("Opphøyd =", tall1 ** tall2)                      # Opphøyer variablene
print("Dividert med nedrunding =", tall1 // tall2)      # Dividerer variablene med nedrunding