Person1 = int(5)
Person2 = int(9)
Person3 = int(2.5)
Person4 = int(21)
Person5 = int(0)

Antall_personer = 5

print ("Gjennomsnitt kake per person er",(Person1 + Person2 + Person3 + Person4 + Person5) // Antall_personer)