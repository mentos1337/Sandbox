Fornavn = "Granit"                                                              # Lager variabel til fornavn
Etternavn = "Salihu"                                                            # Lager variabel til etternavn
Alder = 27                                                                      # Lager variabel til Alder

print("Hei jeg heter", Fornavn, Etternavn, "og er ", Alder, "år gammel")        # Printer ut variablene