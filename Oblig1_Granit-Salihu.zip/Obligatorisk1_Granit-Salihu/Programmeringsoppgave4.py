a = int(6)                      # Definerer variabel som integer
b = int(3)                      # Definerer variabel som integer
c = int(2)                      # Definerer variabel som integer

print("A) ", a + b * c)         # Multipliserer b & c før de blir addert med a
print("B) ", (a + b) * c)       # Adderer a & b før de blir multiplisert med c
print("C) ", a / b / c)         # Dividerer variablene
print("D) ", a / (b / c))       # Dividerer variablene b & c før a