student = {"First_name": "Granit", "Last_name": "Salihu", "Favourite_course": "Programmering 1"}
print(student)


student.update({"Favourite_course": "ITF10219 Programmering 1"})
print(student)


student.update({"Alder": "27"})
print(student)

#Skriv ut studentens fullstendige navn (fornavn og etternavn). 
#Programmatisk endre studentens favorittkurs til å inkludere kursets emnekode: "ITF10219 Programmering 1"
#Programmatisk legg til en alder for studenten i dictionarien. Du kan selv velge hva alderen skal være"