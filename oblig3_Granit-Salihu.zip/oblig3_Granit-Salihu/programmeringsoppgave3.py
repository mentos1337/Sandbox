def print_list(liste):
    for mat in liste:
        print (mat)

Favoritt_retter = {"Sushi", "Pizza", "Kebab"}

print_list(Favoritt_retter)