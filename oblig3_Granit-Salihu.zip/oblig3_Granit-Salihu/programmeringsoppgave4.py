def volumregner(lengde,bredde,høyde):
    volum = lengde*bredde*høyde
    return volum

print(volumregner(4,5,3))
print(volumregner(3,7,5))
print(volumregner(2,4,8))