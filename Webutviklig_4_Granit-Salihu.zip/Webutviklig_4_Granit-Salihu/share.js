const share = document.getElementById("share-menu");

const shareMenu = () =>{
    if(share.style.display == "block"){
        share.style.display ="none";
    }
    else{
        share.style.display = "block";
    };
}